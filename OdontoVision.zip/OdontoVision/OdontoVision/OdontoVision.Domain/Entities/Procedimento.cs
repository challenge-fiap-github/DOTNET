﻿namespace OdontoVision.Domain.Entities
{
    public class Procedimento
    {
        public int Id { get; set; }
        public string Descricao { get; set; }
        public decimal Custo { get; set; }
    }
}
