using OdontoVision.Domain.Entities;
using System.Collections.Generic;

namespace OdontoVision.Domain.Interfaces
{
    public interface IDentistaRepository
    {
        void Adicionar(Dentista dentista);
        IEnumerable<Dentista> ObterTodos();
        Dentista GetById(int id);
        void Atualizar(Dentista dentista);
        void Remover(int id);
    }
}
