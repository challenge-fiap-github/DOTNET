using OdontoVision.Application.DTOs;
using OdontoVision.Domain.Entities;
using OdontoVision.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OdontoVision.Application.Services
{
    public class DentistaService
    {
        private readonly IDentistaRepository _dentistaRepository;

        public DentistaService(IDentistaRepository dentistaRepository)
        {
            _dentistaRepository = dentistaRepository;
        }

        public void CreateDentista(DentistaDTO dentistaDto)
        {
            try
            {
                var dentista = new Dentista
                {
                    Nome = dentistaDto.Nome,
                    Cpf = dentistaDto.Cpf,
                    Especialidade = dentistaDto.Especialidade
                };
                _dentistaRepository.Adicionar(dentista);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao adicionar dentista: {ex.Message}");
                throw;
            }
        }

        public IEnumerable<DentistaDTO> GetAllDentistas()
        {
            try
            {
                return _dentistaRepository.ObterTodos()
                    .Select(d => new DentistaDTO
                    {
                        Id = d.Id,
                        Nome = d.Nome,
                        Cpf = d.Cpf,
                        Especialidade = d.Especialidade
                    });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao obter dentistas: {ex.Message}");
                throw;
            }
        }

        public DentistaDTO GetDentistaById(int id)
        {
            try
            {
                var dentista = _dentistaRepository.GetById(id);
                if (dentista == null) return null;

                return new DentistaDTO
                {
                    Id = dentista.Id,
                    Nome = dentista.Nome,
                    Cpf = dentista.Cpf,
                    Especialidade = dentista.Especialidade
                };
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao obter dentista por ID: {ex.Message}");
                throw;
            }
        }

        public void UpdateDentista(int id, DentistaDTO dentistaDto)
        {
            try
            {
                var dentista = _dentistaRepository.GetById(id);
                if (dentista != null)
                {
                    dentista.Nome = dentistaDto.Nome;
                    dentista.Cpf = dentistaDto.Cpf;
                    dentista.Especialidade = dentistaDto.Especialidade;
                    _dentistaRepository.Atualizar(dentista);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao atualizar dentista: {ex.Message}");
                throw;
            }
        }

        public void DeleteDentista(int id)
        {
            try
            {
                _dentistaRepository.Remover(id);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao deletar dentista: {ex.Message}");
                throw;
            }
        }
    }
}
