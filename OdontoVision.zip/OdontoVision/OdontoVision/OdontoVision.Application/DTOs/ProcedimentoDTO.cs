namespace OdontoVision.Application.DTOs
{
    public class ProcedimentoDTO
    {
        public int Id { get; set; }  // Propriedade adicionada
        public string Descricao { get; set; }
        public decimal Custo { get; set; }
    }
}
