﻿using Microsoft.EntityFrameworkCore;
using OdontoVision.Domain.Entities;

public class OdontoVisionDbContext : DbContext
{
    public OdontoVisionDbContext(DbContextOptions<OdontoVisionDbContext> options) : base(options) { }

    public DbSet<Paciente> Pacientes { get; set; }
    public DbSet<Procedimento> Procedimentos { get; set; }
    public DbSet<Diagnostico> Diagnosticos { get; set; }
    public DbSet<Dentista> Dentistas { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Procedimento>()
            .Property(p => p.Custo)
            .HasPrecision(18, 2);
    }
}
