using OdontoVision.Domain.Entities;
using OdontoVision.Domain.Interfaces;
using OdontoVision.Infrastructure.Context;
using System.Collections.Generic;
using System.Linq;

namespace OdontoVision.Infrastructure.Repositories
{
    public class DentistaRepository : IDentistaRepository
    {
        private readonly OdontoVisionDbContext _context;

        public DentistaRepository(OdontoVisionDbContext context)
        {
            _context = context;
        }

        public void Adicionar(Dentista dentista)
        {
            _context.Dentistas.Add(dentista);
            _context.SaveChanges();
        }

        public IEnumerable<Dentista> ObterTodos()
        {
            return _context.Dentistas.ToList();
        }

        public Dentista GetById(int id)
        {
            return _context.Dentistas.Find(id);
        }

        public void Atualizar(Dentista dentista)
        {
            _context.Dentistas.Update(dentista);
            _context.SaveChanges();
        }

        public void Remover(int id)
        {
            var dentista = GetById(id);
            if (dentista != null)
            {
                _context.Dentistas.Remove(dentista);
                _context.SaveChanges();
            }
        }
    }
}
