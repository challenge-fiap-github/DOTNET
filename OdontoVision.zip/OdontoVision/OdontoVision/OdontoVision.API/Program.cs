using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);

// Configura os serviços da aplicação
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configura o ambiente de produção
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

// Middleware para segurança e arquivos estáticos
//app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();

// Configuração de rotas padrão e rotas personalizadas para Diagnóstico e Procedimento
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapControllerRoute(
    name: "diagnostico",
    pattern: "diagnostico/{action}/{id?}",
    defaults: new { controller = "Diagnostico", action = "Index" });

app.MapControllerRoute(
    name: "procedimento",
    pattern: "procedimento/{action}/{id?}",
    defaults: new { controller = "Procedimento", action = "Index" });

app.Run();
