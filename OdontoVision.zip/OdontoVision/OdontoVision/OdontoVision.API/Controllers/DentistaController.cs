using Microsoft.AspNetCore.Mvc;
using OdontoVision.Application.DTOs;
using OdontoVision.Application.Services;
using System.Collections.Generic;

namespace OdontoVision.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DentistaController : ControllerBase
    {
        private readonly DentistaService _dentistaService;

        public DentistaController(DentistaService dentistaService)
        {
            _dentistaService = dentistaService;
        }

        [HttpPost]
        public IActionResult CreateDentista([FromBody] DentistaDTO dentistaDto)
        {
            _dentistaService.CreateDentista(dentistaDto);
            return Ok("Dentista adicionado com sucesso");
        }

        [HttpGet]
        public ActionResult<IEnumerable<DentistaDTO>> GetAllDentistas()
        {
            var dentistas = _dentistaService.GetAllDentistas();
            return Ok(dentistas);
        }

        [HttpGet("{id}")]
        public ActionResult<DentistaDTO> GetDentistaById(int id)
        {
            var dentista = _dentistaService.GetDentistaById(id);
            if (dentista == null)
                return NotFound();

            return Ok(dentista);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateDentista(int id, [FromBody] DentistaDTO dentistaDto)
        {
            _dentistaService.UpdateDentista(id, dentistaDto);
            return Ok("Dentista atualizado com sucesso");
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteDentista(int id)
        {
            _dentistaService.DeleteDentista(id);
            return Ok("Dentista removido com sucesso");
        }
    }
}
